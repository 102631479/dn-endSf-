let DataRouter = [

    // {
    //     powerShow: true,
    //     icon: 'el-icon-user-solid',
    //     index: 'manager-management',
    //     title: '系统管理',
    //     subs: [{
    //             powerShow: 'm:user',
    //             index: 'manager-management',
    //             title: '用户管理',
    //         },

    //     ],
    // },

    {
        powerShow: true,
        icon: 'el-icon-user-solid',
        index: 'main_port',
        title: '物流管理',
     
    },

  

    // {
    //     powerShow: true,
    //     icon: 'el-icon-user-solid',
    //     index: 'Dn-Table',
    //     title: '表格封装',
    //     subs: [{
    //             powerShow: 'm:user',
    //             index: 'Dn-Table',
    //             title: '表格',
    //         },

    //     ],
    // },




]


let data = () => {
    return DataRouter
}
export default data;