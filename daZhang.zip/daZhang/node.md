
```js
http://115.238.111.66:18220/manage/manage/config/
http://115.238.111.66:18220/manage/manage/user/
http://115.238.111.66:18220/manage/manage/oauth/

```