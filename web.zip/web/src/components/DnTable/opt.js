export default {
    submitBtn: {
      show: false
    },
    resetBtn:{
      show: false,
    },
    // row:{
    //   type: "top",
    //   align:'end',
    // },
    global: {
      // "*": {
       
        col: {
          // span: 20,
          // labelWidth: 10
        },
        // validate: [
        //   {required: true}
        // ]
      // }
    }
  }
