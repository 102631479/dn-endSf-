import {
    maker
} from '@form-create/element-ui'
let makerForm = [
    maker.input('1', 'title', '1', {
        disabled: false
    }),
    maker.input('2', 'title', '2', {
        disabled: false
    }),
    maker.input('3', 'title', '3', {
        disabled: false
    }),
    maker.input('4  ', 'title', '4', {
        disabled: false
    })
]
export default makerForm